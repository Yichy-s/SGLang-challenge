# HW3 - 第三次挑战：多副本 SGLang 路由策略实验

## 1. 实验环境
- **硬件**：云端 RTX 4090 单卡 (24GB)
- **软件版本**：Ubuntu 22.04, SGLang 0.5.14, Ray 2.56.0, Python 3.10
- **模型**：Qwen/Qwen3-0.6B

## 2. 安装方法
```bash
conda create -n sglang_env python=3.10 -y
conda activate sglang_env
apt update && apt install build-essential -y
source /etc/network_turbo
pip install "sglang==0.5.14" "numpy<2" requests aiohttp tqdm transformers -i https://pypi.tuna.tsinghua.edu.cn/simple