import ray
from ray import serve
from base_router import GroupARouter

ray.init(address="auto")
serve.start(http_options={"port": 9000})
handle = serve.run(GroupARouter.bind())
print("A 组部署完成！")