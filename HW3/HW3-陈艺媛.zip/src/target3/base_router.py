import ray
from ray import serve
import requests
import random
from typing import List

SGLANG_BACKENDS = ["http://127.0.0.1:8000", "http://127.0.0.1:8001", "http://127.0.0.1:8002", "http://127.0.0.1:8003"]

@serve.deployment(num_replicas=4, max_ongoing_requests=5, ray_actor_options={"num_gpus": 0.0})
class GroupARouter:
    def __init__(self):
        self.backends = SGLANG_BACKENDS
    async def __call__(self, request):
        body = await request.json()
        backend_url = random.choice(self.backends)
        try:
            resp = requests.post(f"{backend_url}/generate", json=body, timeout=120)
            return resp.json()
        except Exception as e:
            return {"error": str(e), "backend": backend_url}