import time
import asyncio
import aiohttp
import json
import random
import numpy as np

API_URL = "http://127.0.0.1:30000"
CONCURRENCY = 8
NUM_REQUESTS = 32

async def send_streaming_request(session, input_ids):
    payload = {
        "input_ids": input_ids,
        "temperature": 0,
        "max_new_tokens": 16,
        "ignore_eos": True,
        "sampling_seed": 2026,
        "stream": True
    }
    start_time = time.time()
    ttft = None
    token_count = 0
    
    try:
        async with session.post(f"{API_URL}/generate", json=payload) as resp:
            if resp.status != 200:
                return {"status": "error", "error": await resp.text()}
            
            async for line in resp.content:
                if not line: continue
                if ttft is None:
                    ttft = (time.time() - start_time) * 1000
                token_count += 1
            
            end_to_end = (time.time() - start_time) * 1000
            tpot = (end_to_end - ttft) / (token_count - 1) if token_count > 1 else 0
            
            return {"status": 200, "ttft": ttft, "tpot": tpot, "latency": end_to_end}
    except Exception as e:
        return {"status": "error", "error": str(e)}

async def run_benchmark(mode):
    print(f"\n=== 开始测试: {mode} 组 ===")
    async with aiohttp.ClientSession() as session:
        await session.post(f"{API_URL}/flush_cache")
        requests = []
        if mode == "shared_prefix":
            shared_prefix = [random.randint(100, 200) for _ in range(2048)]
            for i in range(NUM_REQUESTS):
                requests.append(shared_prefix + [random.randint(1000, 2000) for _ in range(64)])
        else:
            for i in range(NUM_REQUESTS):
                requests.append([10000 + i] + [random.randint(100, 200) for _ in range(2111)])
        
        semaphore = asyncio.Semaphore(CONCURRENCY)
        async def limited_task(input_ids):
            async with semaphore:
                return await send_streaming_request(session, input_ids)
        
        tasks = [limited_task(req) for req in requests]
        results = await asyncio.gather(*tasks)
        
        successes = [r for r in results if r["status"] == 200]
        success_rate = len(successes) / NUM_REQUESTS * 100
        ttfts = [r["ttft"] for r in successes]
        tpots = [r["tpot"] for r in successes]
        latencies = [r["latency"] for r in successes]
        
        print(f"成功率: {success_rate:.2f}%")
        print(f"TTFT  p50: {np.percentile(ttfts, 50):.2f}ms, p95: {np.percentile(ttfts, 95):.2f}ms")
        print(f"TPOT  p50: {np.percentile(tpots, 50):.2f}ms, p95: {np.percentile(tpots, 95):.2f}ms")
        print(f"端到端延迟 p50: {np.percentile(latencies, 50):.2f}ms, p95: {np.percentile(latencies, 95):.2f}ms")
        
        with open(f"{mode}_stream_results.json", "w") as f:
            json.dump(results, f, indent=2)
        print(f"数据已保存至 {mode}_stream_results.json")

async def main():
    print("执行预热请求...")
    async with aiohttp.ClientSession() as session:
        await send_streaming_request(session, [random.randint(100, 200) for _ in range(2112)])
    print("预热完成")
    
    await run_benchmark("shared_prefix")
    await run_benchmark("dispersed_prefix")

if __name__ == "__main__":
    asyncio.run(main())