import time
import asyncio
import aiohttp
import json
import random
import numpy as np

API_URL = "http://127.0.0.1:30000"
CONCURRENCY = 8
NUM_REQUESTS = 32

async def send_request(session, input_ids):
    payload = {
        "input_ids": input_ids,
        "temperature": 0,
        "max_new_tokens": 16,
        "ignore_eos": True,
        "sampling_seed": 2026
    }
    start = time.time()
    try:
        async with session.post(f"{API_URL}/generate", json=payload) as resp:
            data = await resp.json()
            latency = (time.time() - start) * 1000
            cached = data.get("meta_info", {}).get("cached_tokens", 0)
            prompt_tokens = data.get("meta_info", {}).get("prompt_tokens", 0)
            return {"status": 200, "latency": latency, "cached_tokens": cached, "prompt_tokens": prompt_tokens}
    except Exception as e:
        return {"status": "error", "error": str(e)}

async def run_benchmark(mode):
    print(f"\n=== 开始测试: {mode} 组 ===")
    async with aiohttp.ClientSession() as session:
        # 1. 清空缓存
        await session.post(f"{API_URL}/flush_cache")
        print("已清空缓存")
        
        # 2. 构造输入
        requests = []
        if mode == "shared_prefix":
            shared_prefix = [random.randint(100, 200) for _ in range(2048)]
            for i in range(NUM_REQUESTS):
                requests.append(shared_prefix + [random.randint(1000, 2000) for _ in range(64)])
        else:
            for i in range(NUM_REQUESTS):
                requests.append([10000 + i] + [random.randint(100, 200) for _ in range(2111)])
        
        # 3. 并发发送
        semaphore = asyncio.Semaphore(CONCURRENCY)
        async def limited_task(input_ids):
            async with semaphore:
                return await send_request(session, input_ids)
        
        tasks = [limited_task(req) for req in requests]
        results = await asyncio.gather(*tasks)
        
        # 4. 统计
        successes = [r for r in results if r["status"] == 200]
        success_rate = len(successes) / NUM_REQUESTS * 100
        total_cached = sum(r["cached_tokens"] for r in successes)
        total_prompt = sum(r["prompt_tokens"] for r in successes)
        hit_rate = total_cached / total_prompt * 100 if total_prompt > 0 else 0
        prefill_tokens = total_prompt - total_cached
        
        latencies = [r["latency"] for r in successes]
        p50 = np.percentile(latencies, 50) if latencies else 0
        p95 = np.percentile(latencies, 95) if latencies else 0
        
        print(f"成功率: {success_rate:.2f}%")
        print(f"缓存命中率: {hit_rate:.2f}%")
        print(f"实际执行 Prefill tokens: {prefill_tokens}")
        print(f"延迟 p50: {p50:.2f}ms, p95: {p95:.2f}ms")
        
        with open(f"{mode}_results.json", "w") as f:
            json.dump(results, f, indent=2)
        print(f"数据已保存至 {mode}_results.json")

async def main():
    # 预热
    print("执行预热请求...")
    async with aiohttp.ClientSession() as session:
        warmup = [random.randint(100, 200) for _ in range(2112)]
        await send_request(session, warmup)
    print("预热完成")
    
    await run_benchmark("shared_prefix")
    await run_benchmark("dispersed_prefix")

if __name__ == "__main__":
    asyncio.run(main())